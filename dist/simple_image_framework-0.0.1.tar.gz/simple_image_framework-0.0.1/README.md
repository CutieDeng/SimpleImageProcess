# Simple Image Framework

This image framework is built for a simple usage of processing images with python. 
It is based on the [Pillow](https://pillow.readthedocs.io/en/stable/) library, (PIL fork). 

I set it for my own usage, but I hope it will be useful for you too. 

## Installation 

## Usage 

详见 tests 文件夹中的参考样例 

## Contributing 

- Cutie Deng : [Github](github.com/CutieDeng) mail: Dengzr2020@mail.sustech.edu.cn
from image_processing_framework import color_terminal 

color_terminal.debug('start debug info ~ ') 
color_terminal.info('start info info ~ ') 
color_terminal.warn('start warn info ~ ') 
color_terminal.error('start error info ~ ') 
color_terminal.info('end of program with exit code 0. ')

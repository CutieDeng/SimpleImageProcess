from image_processing_framework import core 

# Attempt to run the framework , as the identity function 

if __name__ == '__main__': 
    core.frame_run() 